<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">

                <div class="col-md-8">
                    <h1>Product page</h1>
                    <table>
                        <tr>
                            <th>name</th>
                            <th>description</th>
                            <th>price</th>
                            <th>image</th>
                            <th>Edit</th>
                            <th>Delete</th>
                        </tr>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td> <?php echo e($product->name); ?></td>
                                <td> <?php echo e($product->description); ?></td>
                                <td> <?php echo e($product->price); ?></td>
                                <td><img src="<?php echo e($product->image); ?>" width="100px" height="100px" alt=""> </td>
                                <td>
                                    <a href="<?php echo e(route('products.edit', ['id' => $product->id])); ?>" class="btn btn-primary">Edit</a>
                                </td>
                                <td>
                                    <form action="<?php echo e(route('products.destroy', ['id' => $product->id])); ?>" method="post">
                                        <?php echo e(csrf_field()); ?>

                                        <?php echo e(method_field('DELETE')); ?>

                                        <button class="btn btn-danger">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>

                </div>

        </div>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>